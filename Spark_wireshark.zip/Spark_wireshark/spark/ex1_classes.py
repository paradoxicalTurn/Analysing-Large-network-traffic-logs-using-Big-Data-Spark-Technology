class LogEntry:
    """A simple data object"""
    def __init__(self, time, src_address, src_port, proto, header_length):
        self.time      = time
        self.src_address    = src_address
        self.src_port   = src_port
        self.proto  = proto
        self.header_length = header_length

    def __str__(self):
        return "LogEntry {\n\ttime: %s,\n\tsrc_address: %s,\n\tsrc_port: %s,\n\tproto: %s,\n\theader_length: %s}" \
               % (self.time, self.src_address, self.src_port, self.proto, self.header_length)

    def __repr__(self):
        return "LogEntry {\n\ttime: %s,\n\tsrc_address: %s,\n\tsrc_mac: %s,\n\tproto: %s,\n\theader_length: %s}" \
               % (self.time, self.src_address, self.src_port, self.proto, self.header_length)
