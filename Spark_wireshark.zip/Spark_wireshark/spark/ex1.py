from __future__ import print_function
import os
import sys

from pyspark import SparkContext
from ex1_classes import LogEntry



def processFile(line):
    """
    This function will parse a line from the input file and return a LogEntry object that represents that line;
    Sample line: 'Apr  5 06:54:32 (none) sshd[12074]: Failed password for root from 1.30.20.148 port 7691 ssh2'
    """
    w = line
    w = w.split()

    port = ""
    #if(len(w)==8):
    #    port = "Not found"
    #else: 
    #    port = str(w[8])

    time = ""
    src_address = ""
    src_port = ""
    proto=""
    header_length = 0

    k = 0
    for val in w:
        if(k==1):
            time = w[1]
        elif(k==3):
            src_address = w[3]
            #d = w[3]
            #if(d.startswith("67.")):
            #    src_address = d
        elif(k==6):
            proto = w[6]	
        elif(k==7):
            header_length = w[7]
       
        k = k + 1

    #time = w[1]
    #src_address = w[3]
    src_port = port
    #proto = w[6]
    #header_length = w[7]
   
    return LogEntry(time, src_address, src_port, proto, header_length)


if __name__ == '__main__':

    if len(sys.argv) != 3:
        print("Missing parameters\n"\
              "Usage: ex1.py <inputFile> <outputFolder>", file = sys.stderr)
        exit(-1)

    filespath = sys.argv[1]
    output_folder = sys.argv[2]
    if not os.path.isdir(output_folder):
        print("Can not find output directory: '%s'" % output_folder, file=sys.stderr)
        exit(-1);

    sc = SparkContext("local", "Exercise - 1: Log Parser App")
    finalRDD = sc.emptyRDD()
    tempRDD = sc.emptyRDD()

    for path,dirs,files in os.walk(filespath):
        for fn in files:
            file_name = os.path.join(path, fn)
            print (file_name)
            folder_path = os.path.dirname(file_name)
            #while(1):
            #    if os.path.dirname(folder_path) == filespath:
            #        break;
            #    folder_path = os.path.dirname(folder_path)
	    authLog = sc.textFile(file_name)

	    logEntries = authLog.map(processFile).cache()

	    #logEntries = logEntries.map(lambda x : ((x.src_address, x.src_port, x.time, x.proto), (x.header_length,1))).reduceByKey(lambda a,b : (a[0], a[1]+b[1]))

	    logEntries = logEntries.map(lambda x : ((x.src_address, x.time, x.proto), (x.header_length,1))).reduceByKey(lambda a,b : (a[0], a[1]+b[1]))

            finalRDD = tempRDD.union(logEntries)
            tempRDD = finalRDD

    #finalRDD = finalRDD.reduceByKey(lambda a,b : (a[0], a[1]+b[1]))
    #logEntries = finalRDD.map(lambda x: (("Source IP="+str(x[0][0]),"Source port="+str(x[0][1]),x[0][2],x[0][3]),("Header Length="+str(x[1][0]),"Number of packets="+str(x[1][1]))))

    finalRDD = finalRDD.reduceByKey(lambda a,b : (a[0], a[1]+b[1])).sortBy(lambda x: x[0][0])
    #finalRDD = finalRDD.map(lambda x: ((x[0][0], x[0][1], x[0][2]),("Header Length="+str(x[1][0]),"Number of packets="+str(x[1][1]))) if(x[1][1]>5000) else (("","",""),("","")))
    #finalRDD = finalRDD.reduceByKey(lambda a,b : a+b)
    finalRDD = finalRDD.map(lambda x: ((x[0][0], x[0][1], x[0][2]),("Header Length = "+str(x[1][0])," Number of packets = "+str(x[1][1]))))

    finalRDD.saveAsTextFile(os.path.join(output_folder, "Log Output"))

