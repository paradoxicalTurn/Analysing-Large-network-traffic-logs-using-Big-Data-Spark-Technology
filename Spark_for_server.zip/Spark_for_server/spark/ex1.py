from __future__ import print_function
import os
import sys

from pyspark import SparkContext
from ex1_classes import LogEntry



def parseFailedPasswordEntry(line):
    """
    This function will parse a line from the input file and return a LogEntry object that represents that line;
    Sample line: 'Apr  5 06:54:32 (none) sshd[12074]: Failed password for root from 1.30.20.148 port 7691 ssh2'
    """
    w = line
    w = w.split("FERRET")

    time = w[0]
    temp = w[1].split("MAC=")
    imp_column = temp[1].split(" SRC=")
    mac_address = imp_column[0]
    
    imp2 = imp_column[1].split(" DST=")
    src_address = imp2[0]

    imp3 = imp2[1].split(" PROTO=")
    j = imp3[1]
    
    imp4 = j.split(" SPT=")
    proto = imp4[0]

    #imp5 = imp4[1].split("DPT=")
    src_port = imp4[0]
   
    return LogEntry(time, src_address, mac_address, src_port, proto, '')


def isFailedPasswordEntry(line):
    return "IN=eth1" in line

if __name__ == '__main__':

    if len(sys.argv) != 3:
        print("Missing parameters\n"\
              "Usage: ex1.py <inputFile> <outputFolder>", file = sys.stderr)
        exit(-1)

    #filename = "/home/gurc/src/spark/data/02-auth.log"
    filename = sys.argv[1]
    if not os.path.isfile(filename):
        print("Can not find input file : '%s'"%filename, file = sys.stderr)
        exit(-1);

    output_folder = sys.argv[2]
    if not os.path.isdir(output_folder):
        print("Can not find output directory: '%s'" % output_folder, file=sys.stderr)
        exit(-1);

    sc = SparkContext("local", "Exercise - 1: Log Parser App")


    authLog = sc.textFile(filename)

    logEntries = authLog.filter(isFailedPasswordEntry)\
                        .map(parseFailedPasswordEntry)\
                        .cache()

    logEntries.saveAsTextFile(os.path.join(output_folder, "s01-logEntries"))

    #sortedUsernameFrequency = logEntries.map(lambda entry: (entry.username, 1))\
    #                            .reduceByKey(lambda a, b: a+b)\
    #                            .sortBy((lambda x: x[1]), ascending=False)

    """
    Save sortedUsernameFrequency to disk
    --------------------------------------
    1) Save to disk by calling saveAsTextFile
        use os.path.join to concat paths: output_folder + filename
    """
    #sortedUsernameFrequency.saveAsTextFile(os.path.join(output_folder, "s01-sortedUsernameFrequency"))


