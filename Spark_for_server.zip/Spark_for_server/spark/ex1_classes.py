class LogEntry:
    """A simple data object"""
    def __init__(self, time, src_ip, src_mac, src_port, prototype, length):
        self.time      = time
        self.src_ip    = src_ip
        self.src_mac   = src_mac
        self.src_port  = src_port
        self.prototype = prototype
        self.length    = length

    def __str__(self):
        return "LogEntry {\n\ttime: %s,\n\tsrc_ip: %s,\n\tsrc_mac: %s,\n\tsrc_port: %s,\n\tprototype: %s,\n\tlength: %s}" \
               % (self.time, self.src_ip, self.src_mac, self.src_port, self.prototype, self.length)

    def __repr__(self):
        return "LogEntry {\n\ttime: %s,\n\tsrc_ip: %s,\n\tsrc_mac: %s,\n\tsrc_port: %s,\n\tprototype: %s,\n\tlength: %s}" \
               % (self.time, self.src_ip, self.src_mac, self.src_port, self.prototype, self.length)
