class LogEntry:
    """A simple data object"""
    def __init__(self, time, username, rawInput):
        self.time = time
        self.username = username
        self.rawInput = rawInput

    def __str__(self):
        return "LogEntry {\n\ttime: %s,\n\tusername: %s,\n\trawInput: %s\n}" \
               % (self.time, self.username, self.rawInput)

    def __repr__(self):
        return "LogEntry {\n\ttime: %s,\n\tusername: %s,\n\trawInput: %s\n}" \
               % (self.time, self.username, self.rawInput)
