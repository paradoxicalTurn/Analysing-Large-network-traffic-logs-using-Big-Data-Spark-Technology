from __future__ import print_function
import os
import sys
import re

from pyspark import SparkContext
from ex1_classes import LogEntry



def processUnknown(line):
    """
    This function will parse a line from the input file and return a LogEntry object that represents that line;
    Sample line: 'Apr  5 06:54:32 (none) sshd[12074]: Failed password for root from 1.30.20.148 port 7691 ssh2'
    """
    w = line

    q = w.split("FERRET")

    time = q[0]
    #temp = w[1].split("user=<")
    #username = temp[1].split(">,")[0]
    """
    w -> ['root', '1.30.20.148 port 7691 ssh2']
    
    username = w[0]
    if "invalid user " in username:
        # Clear the user name if it contains 'invalid user' string
        username = username.split("invalid user ")[1]
    w = w[1].split(" port ")
    
    w -> ['1.30.20.148', '7691 ssh2']
    
    remoteIp = w[0]
    w = w[1].split(' ')
    """
    #w -> ['7691', 'ssh2']
    
    #remotePort = w[0]
    #version = w[1]

    d = w.split("unknown[")

    username = d[1]
    username = username.split("]")[0]
    #username = re.sub(r'[]', r'', username)

    return LogEntry(time, username, line)


def isUnknown(line):
    #return "auth failed" in line
    return "connect from unknown[67." in line

if __name__ == '__main__':

    if len(sys.argv) != 3:
        print("Missing parameters\n"\
              "Usage: ex1.py <inputFile> <outputFolder>", file = sys.stderr)
        exit(-1)

    #filename = "/home/gurc/src/spark/data/02-auth.log"
    filename = sys.argv[1]
    if not os.path.isfile(filename):
        print("Can not find input file : '%s'"%filename, file = sys.stderr)
        exit(-1);

    output_folder = sys.argv[2]
    if not os.path.isdir(output_folder):
        print("Can not find output directory: '%s'" % output_folder, file=sys.stderr)
        exit(-1);

    sc = SparkContext("local", "Exercise - 1: Log Parser App")

    authLog = sc.textFile(filename)
    logEntries = authLog.filter(isUnknown).map(processUnknown)

    logEntries = logEntries.map(lambda x: ((x.username, x.time),1)).reduceByKey(lambda a,b : a + b)

    logEntries.saveAsTextFile(os.path.join(output_folder, "s01-logEntries"))

